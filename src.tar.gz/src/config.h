#ifndef _CONFIG_H
#define _CONFIG_H

#define NULL 0

#define SERIAL_PRINT 1
#define RPI 0
#define DEBUG 1
#define VMEM 0

#endif
